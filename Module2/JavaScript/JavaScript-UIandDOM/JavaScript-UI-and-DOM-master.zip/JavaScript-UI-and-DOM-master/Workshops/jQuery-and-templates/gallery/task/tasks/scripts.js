/* globals $ */

//function solve() {
  $.fn.gallery = function () {
    // your solution here
  };
//}
//module.exports = solve;