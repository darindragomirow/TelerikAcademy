## jQuery plugins

- Task 1: Gallery
  - Task 2 from **JS UI & DOM Exam 2014**
  - [Description](gallery/task)
  - [Steps for building a solution](gallery)

- Task 2: Tabs
  - Task 2 from **JS UI & DOM Exam 2015**

  - [Description](datepicker/task)
  - [Steps for building a solution](datepicker)

## HTML templates

- Task 1: List Template
  - Task 3 from **JS UI & DOM Exam 2014**
  - [Description](list-template/task)
  - [Steps for building a solution](list-template)

- Task 2: Calendar Template
  - Task 3 from **JS UI & DOM Exam 2015**
  - [Description](calendar-template/task)
  - [Steps for building a solution](calendar-template)
