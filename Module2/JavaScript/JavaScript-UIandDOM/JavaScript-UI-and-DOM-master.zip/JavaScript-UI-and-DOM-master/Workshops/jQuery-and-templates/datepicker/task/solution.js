﻿function solve() {
    $.fn.datepicker = function () {
        
    };
};

if(typeof module !== 'undefined') {
    module.exports = solve;
}