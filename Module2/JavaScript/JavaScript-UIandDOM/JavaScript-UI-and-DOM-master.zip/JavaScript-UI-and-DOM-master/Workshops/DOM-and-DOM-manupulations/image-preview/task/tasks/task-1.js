/* globals module */
function solve() {
    return function (selector, items) {
      
    };
}

module.exports = solve;