#   Workshops for DOM manipulations


-   Task 1: Items Control
    -   Task 1 from **JS UI & DOM Exam 2015**
    -   [Description](items-control/task)
    -   [Steps for building a solution](items-control)

-   Task 1: Image Preview
    -   Task 1 from **JS UI & DOM Exam 2014**
    -   [Description](image-preview/task)
    -   [Steps for building a solution](image-preview)