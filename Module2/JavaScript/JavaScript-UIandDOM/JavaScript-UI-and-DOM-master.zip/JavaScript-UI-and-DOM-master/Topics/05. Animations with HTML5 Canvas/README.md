<!-- section start -->
<!-- attr: { hasScriptWrapper:true, id:"title" class:"slide-title" } -->
<h1>Animations with HTML5 Canvas</h1>
<h2>Moving things, fading things</h2>
<aside class="signature">
    <p class="signature-course">JavaScript DOM & UI</p>
    <p class="signature-initiative">Telerik Software Academy</p>
    <a href="https://telerikacademy.com" class="signature-link">https://telerikacademy.com</a>
</aside>
