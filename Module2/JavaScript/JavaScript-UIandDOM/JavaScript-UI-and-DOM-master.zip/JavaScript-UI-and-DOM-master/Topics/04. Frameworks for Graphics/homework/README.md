#Frameworks for Graphics (KineticJS)

##Task 1
**Optional, no extra points, no deadline**

Using Kinetic create a family tree


_Example:_

    var familyMembers = [{
      mother: 'Maria Petrova',
      father: 'Georgi Petrov',
      children: ['Teodora Petrova', 'Peter Petrov']
    }, {
      mother: 'Petra Stamatova',
      father: Todor Stamatov',
      children: ['Maria Petrova']
    }] 

<img src="imgs/hw-family-tree.png" />
