function solve(){
  return function(selector){
    
  };
}

module.exports = solve;