$.fn.lists = function (lists) {
    
}