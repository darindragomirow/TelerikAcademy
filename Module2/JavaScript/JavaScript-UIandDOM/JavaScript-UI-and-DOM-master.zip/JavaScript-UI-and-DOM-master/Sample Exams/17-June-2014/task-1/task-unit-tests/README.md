#HTML Templates
_For instructions on how to run the tests, check the following link: 
https://github.com/TelerikAcademy/JavaScript-UI-and-DOM/blob/master/README.md#user-content-preparing-the-local-machine-for-unit-testing-with-mocha-and-chai_

* You can find the task assignment at https://github.com/TelerikAcademy/JavaScript-UI-and-DOM/blob/master/Sample%20Exams/17-June-2014/task-1/README.md
