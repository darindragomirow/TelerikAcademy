function solve() {
  return function () {
    /* globals $ */
    $.fn.gallery = function () {
    };
  };
}

module.exports = solve;