﻿namespace PackageManager.Enums
{
    public enum VersionType
    {
        alpha = 0,
        beta = 1,
        rc = 2,
        final = 3
        
    }
}
