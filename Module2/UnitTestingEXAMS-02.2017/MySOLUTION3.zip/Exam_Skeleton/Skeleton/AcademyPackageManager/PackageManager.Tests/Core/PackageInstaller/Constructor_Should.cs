﻿using Moq;
using NUnit.Framework;
using PackageManager.Core.Contracts;
using PackageManager.Models.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PackageManager.Tests.Core.PackageInstaller
{
    [TestFixture]
    class Constructor_Should
    {
        [Test]
        public void CallRestorePackages_WhenInvoked()
        {
            
        }

    }
}
